import axios from 'axios'
export function getSearchs(search: string) {
  return axios.get(
    `https://frontend-test-api.digitalcreative.cn/?no-throttling=true&search=${search}`
  )
}
