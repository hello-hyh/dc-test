<script setup lang="ts">
const { modelValue } = defineProps({
  modelValue: {
    type: String,
    default: ''
  }
})
const emits = defineEmits(['update:modelValue'])

const onChange = (e: any) => {
  emits('update:modelValue', e.target.value ?? '')
}
</script>
<template>
  <div class="search-body-warp">
    {{ modelValue }}
    <img class="search-body__icon" src="@/assets/search-icon.png" />
    <input
      :value="modelValue"
      class="search-body"
      placeholder="Search technologgies we use DC..."
      @blur="onChange"
    />
  </div>
</template>
<style lang="less">
.search-body__tips--error {
  border: 3px solid #ed2e7e;
}
.search-body__tips--active {
  border: 3px solid #6833ff;
}
.search-body-warp {
  width: 100%;
  height: 74px;
  position: relative;
  background: #f2f4f8;
  border-radius: 12px;

  display: flex;
}
.search-body {
  padding: 24px;
  padding-left: 60px;

  background-color: transparent;
  border: 3px solid #f2f4f8;
  border-radius: 12px;

  font-weight: 500;
  font-size: 20px;
  line-height: 26px;
  color: #000000;

  width: 100%;
  &:focus,
  &:active {
    outline: none;
    .search-body__tips--active;
  }
}
.search-body__icon {
  width: 24px;
  height: 24px;

  position: absolute;
  top: 24px;
  left: 24px;
}
</style>
