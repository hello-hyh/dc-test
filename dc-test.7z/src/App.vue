<script setup lang="ts">
import { ref } from '@vue/reactivity'
import Search from './components/search.vue'
import Badge from './components/badge.vue'
import { getSearchs } from './apis/search'
import { watchEffect } from 'vue'
import Card from './components/card.vue'
const badgeList = ref(['Languages', 'Build', 'Design', 'Cloud'])
const inputVal = ref('')
const resultList = ref([])
watchEffect(async () => {
  const { data } = await getSearchs(inputVal.value)
  resultList.value = data
})
</script>

<template>
  {{ inputVal }}
  <div class="app-channel">
    <Search v-model="inputVal"></Search>
    <div class="app-tab">
      <Badge
        v-for="b in badgeList"
        :key="`_${b}`"
        :text="b"
        @on-select="t => (inputVal = t)"
      ></Badge>
    </div>
    <div class="app-result">
      <Card v-for="r in resultList"></Card>
    </div>
  </div>
</template>

<style lang="less">
#app {
  width: 100%;
  height: 100%;
  display: flex;
  flex-flow: row;
  justify-content: center;
  align-items: center;
  .app-channel {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 24px;

    width: 690px;
    height: 600px;

    background: #ffffff;
    border-radius: 20px;

    box-shadow: 0px 30px 60px -30px rgba(0, 0, 0, 0.25),
      0px 50px 100px -20px rgba(50, 50, 93, 0.25);
  }
  .app-tab {
    margin: 20px 0;
    width: 100%;
    display: flex;
  }
  .app-result {
    width: 100%;
  }
}
</style>
